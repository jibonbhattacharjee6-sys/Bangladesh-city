BANGLADESH CITY - ANDROID PHASE 1 UNITY PROJECT
================================================

এটি একটি Unity project starter, সম্পূর্ণ GTA-মানের গেম নয় এবং APK ফাইলও আগে থেকে তৈরি নেই।
এতে Phase 1-এর scene generator, player movement, third-person camera, arcade car এবং touch UI scripts আছে।

প্রয়োজন:
- Unity Hub
- Unity 2022.3 LTS (অথবা Unity 6 LTS; project import করে compatibility check করুন)
- Android Build Support
- Android SDK & NDK Tools
- OpenJDK
- Windows-এ Unity Editor

প্রজেক্ট চালু:
1. ZIP Extract করুন।
2. Unity Hub > Add > Extract করা BANGLADESH_CITY_ANDROID_PHASE1 folder নির্বাচন করুন।
3. Unity Editor-এ project খুলুন এবং import শেষ হতে দিন।
4. Menu থেকে Bangladesh City > Build Phase 1 Demo Scene নির্বাচন করুন।
5. Assets/Scenes/BangladeshCity_Phase1.unity খুলুন।
6. Play চাপুন।

PC Controls:
- WASD: হাঁটা / গাড়ি চালানো
- Shift: দৌড়
- Space: লাফ
- Mouse: ক্যামেরা দেখা
- E: গাড়িতে ওঠা/নামা

Android APK build:
1. File > Build Settings (বা Unity 6-এ Build Profiles) খুলুন।
2. Android নির্বাচন করে Switch Platform চাপুন।
3. Player Settings-এ Package Name দিন: com.codling.bangladeshcity
4. Minimum API Level হিসেবে আপনার Unity/ডিভাইস সমর্থিত মান বেছে নিন।
5. Orientation: Landscape.
6. Scripting Backend: IL2CPP; Target Architectures: ARM64.
7. Build চাপুন এবং APK save location নির্বাচন করুন।
8. APK ফোনে install করে পরীক্ষা করুন।

গুরুত্বপূর্ণ:
- Android Build Support ইনস্টল না থাকলে APK build হবে না।
- Touch joystick ও action buttons Scene generator দিয়ে তৈরি হয়।
- Camera touch area screen-এর ডানদিকে drag করে camera ঘোরানোর জন্য।
- বর্তমান গাড়ির controller একটি সাধারণ arcade prototype; উন্নত wheel physics নয়।
- City buildings placeholder cube; আসল Bangladesh assets পরে যোগ করতে হবে।
- Android-এ 60 FPS নিশ্চিত নয়। ফোনভেদে graphics/performance আলাদা হবে।
- Editor script scene ও material তৈরি করে; build করার আগে Console-এর error পরীক্ষা করুন।
- এই package-এ Unity Editor নিজে বা Android SDK অন্তর্ভুক্ত নেই।
