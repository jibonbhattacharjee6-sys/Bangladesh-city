#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public static class Phase1Setup
{
    [MenuItem("Bangladesh City/Build Phase 1 Demo Scene")]
    public static void BuildScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        CreateMaterial("RoadMat", new Color(0.16f,0.17f,0.18f));
        CreateMaterial("SidewalkMat", new Color(0.55f,0.53f,0.48f));
        CreateMaterial("GrassMat", new Color(0.20f,0.42f,0.20f));
        CreateMaterial("BuildingA", new Color(0.72f,0.62f,0.48f));
        CreateMaterial("BuildingB", new Color(0.55f,0.68f,0.72f));
        CreateMaterial("PlayerMat", new Color(0.15f,0.35f,0.85f));
        CreateMaterial("CarMat", new Color(0.75f,0.12f,0.10f));

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "City_Ground";
        ground.transform.localScale = new Vector3(12,1,12);
        ground.GetComponent<Renderer>().sharedMaterial = Mat("GrassMat");

        MakeCube("Main_Road", new Vector3(0,0.03f,0), new Vector3(12,0.12f,100), "RoadMat");
        MakeCube("Left_Sidewalk", new Vector3(-7.2f,0.15f,0), new Vector3(2.4f,0.3f,100), "SidewalkMat");
        MakeCube("Right_Sidewalk", new Vector3(7.2f,0.15f,0), new Vector3(2.4f,0.3f,100), "SidewalkMat");
        for (int i=0;i<15;i++)
        {
            float z = -45 + i*6.5f;
            MakeCube("Road_Dash_"+i, new Vector3(0,0.11f,z), new Vector3(0.18f,0.025f,3.2f), "SidewalkMat");
        }

        for (int i=0;i<16;i++)
        {
            float z = -43 + i*5.8f;
            float side = (i%2==0) ? -1 : 1;
            float h = Random.Range(5f,13f);
            float w = Random.Range(5f,8f);
            GameObject b = MakeCube("Bangladesh_Building_"+i,
                new Vector3(side*(10+w/2),h/2,z), new Vector3(w,h,Random.Range(5f,9f)),
                i%2==0 ? "BuildingA" : "BuildingB");
            MakeCube("Building_Roof_"+i,
                b.transform.position + Vector3.up*(h/2+0.12f),
                new Vector3(w+0.25f,0.25f,b.transform.localScale.z+0.25f), "RoadMat");
        }

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player";
        player.transform.position = new Vector3(-3,1.1f,-8);
        player.GetComponent<Renderer>().sharedMaterial = Mat("PlayerMat");
        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height=1.9f; cc.radius=0.38f; cc.center=new Vector3(0,0,0);
        PlayerMotor motor = player.AddComponent<PlayerMotor>();

        Camera cam = Camera.main;
        cam.transform.position = new Vector3(0,4,-14);
        ThirdPersonCamera follow = cam.gameObject.AddComponent<ThirdPersonCamera>();
        follow.target = player.transform;
        motor.cameraTransform = cam.transform;

        GameObject car = MakeCube("Starter_Car", new Vector3(3,0.85f,1),
            new Vector3(2,1.3f,4), "CarMat");
        Rigidbody rb = car.AddComponent<Rigidbody>();
        rb.mass=1100;
        ArcadeCar arcadeCar = car.AddComponent<ArcadeCar>();
        GameObject exit = new GameObject("ExitPoint");
        exit.transform.SetParent(car.transform);
        exit.transform.localPosition = new Vector3(-1.7f,0,0);
        arcadeCar.exitPoint=exit.transform;

        GameObject system = new GameObject("VehicleSystem");
        VehicleSystem vs = system.AddComponent<VehicleSystem>();
        vs.player=player.transform; vs.playerMotor=motor; vs.gameCamera=follow;
        system.AddComponent<GameInputFrameReset>();

        BuildCanvas();

        GameObject light = new GameObject("Sun");
        Light sun = light.AddComponent<Light>();
        sun.type=LightType.Directional; sun.intensity=1.15f;
        light.transform.rotation=Quaternion.Euler(50,-30,0);

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/BangladeshCity_Phase1.unity");
        Selection.activeGameObject = player;
        EditorUtility.DisplayDialog("BANGLADESH CITY",
            "Phase 1 demo scene created. Press Play to test. Configure Android Build Support before making APK.", "OK");
    }

    static void BuildCanvas()
    {
        GameObject eventObj = new GameObject("EventSystem");
        eventObj.AddComponent<EventSystem>();
        eventObj.AddComponent<StandaloneInputModule>();

        GameObject canvasObj = new GameObject("MobileCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasObj.GetComponent<Canvas>();
        canvas.renderMode=RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler=canvasObj.GetComponent<CanvasScaler>();
        scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution=new Vector2(1920,1080);

        Text title=MakeText(canvasObj.transform,"BANGLADESH CITY",new Vector2(0,1),new Vector2(0,1),
            new Vector2(30,-25),new Vector2(500,70),38,TextAnchor.MiddleLeft);
        title.color=Color.white;

        Text help=MakeText(canvasObj.transform,"Joystick: Move | Shift: Run | Space: Jump | E: Vehicle",
            new Vector2(0,1),new Vector2(0,1),new Vector2(30,-90),new Vector2(900,50),22,TextAnchor.MiddleLeft);
        help.color=Color.white;

        GameObject joystick = MakePanel(canvasObj.transform,"MoveJoystick",
            new Vector2(0,0),new Vector2(0,0),new Vector2(160,160),new Vector2(240,240),
            new Color(0.1f,0.1f,0.1f,0.35f));
        Image joyImage=joystick.GetComponent<Image>();
        RectTransform joyRect=joystick.GetComponent<RectTransform>();
        GameObject handle=MakePanel(joystick.transform,"Handle",new Vector2(.5f,.5f),new Vector2(.5f,.5f),
            Vector2.zero,new Vector2(95,95),new Color(.8f,.8f,.8f,.65f));
        VirtualJoystick vj=joystick.AddComponent<VirtualJoystick>();
        vj.background=joyRect; vj.handle=handle.GetComponent<RectTransform>();

        MakeActionButton(canvasObj.transform,"JUMP",new Vector2(1,0),new Vector2(1,0),
            new Vector2(-165,175),TouchActionButton.ActionType.Jump);
        MakeActionButton(canvasObj.transform,"RUN",new Vector2(1,0),new Vector2(1,0),
            new Vector2(-165,310),TouchActionButton.ActionType.Run);
        MakeActionButton(canvasObj.transform,"USE",new Vector2(1,0),new Vector2(1,0),
            new Vector2(-340,175),TouchActionButton.ActionType.Interact);
        MakeActionButton(canvasObj.transform,"BRAKE",new Vector2(1,0),new Vector2(1,0),
            new Vector2(-340,310),TouchActionButton.ActionType.Brake);

        GameObject lookArea=MakePanel(canvasObj.transform,"CameraTouchArea",
            new Vector2(.45f,0),new Vector2(1,1),Vector2.zero,Vector2.zero,new Color(1,1,1,0.01f));
        TouchLookArea look=lookArea.AddComponent<TouchLookArea>();
        lookArea.transform.SetAsFirstSibling();
    }

    static void MakeActionButton(Transform parent,string label,Vector2 amin,Vector2 amax,Vector2 pos,
        TouchActionButton.ActionType type)
    {
        GameObject go=MakePanel(parent,label,amin,amax,pos,new Vector2(125,105),new Color(.08f,.12f,.2f,.72f));
        TouchActionButton action=go.AddComponent<TouchActionButton>();
        action.actionType=type;
        Text t=MakeText(go.transform,label,new Vector2(0,0),new Vector2(1,1),Vector2.zero,Vector2.zero,22,TextAnchor.MiddleCenter);
        t.color=Color.white;
    }

    static GameObject MakePanel(Transform parent,string name,Vector2 amin,Vector2 amax,Vector2 pos,Vector2 size,Color color)
    {
        GameObject go=new GameObject(name,typeof(RectTransform),typeof(Image));
        go.transform.SetParent(parent,false);
        RectTransform rt=go.GetComponent<RectTransform>();
        rt.anchorMin=amin; rt.anchorMax=amax; rt.anchoredPosition=pos; rt.sizeDelta=size;
        go.GetComponent<Image>().color=color;
        return go;
    }

    static Text MakeText(Transform parent,string value,Vector2 amin,Vector2 amax,Vector2 pos,Vector2 size,int font,TextAnchor anchor)
    {
        GameObject go=new GameObject("Text_"+value,typeof(RectTransform),typeof(Text));
        go.transform.SetParent(parent,false);
        RectTransform rt=go.GetComponent<RectTransform>();
        rt.anchorMin=amin; rt.anchorMax=amax; rt.anchoredPosition=pos; rt.sizeDelta=size;
        Text t=go.GetComponent<Text>();
        t.text=value; t.font=Resources.GetBuiltinResource<Font>("Arial.ttf");
        t.fontSize=font; t.alignment=anchor; t.raycastTarget=false;
        return t;
    }

    static GameObject MakeCube(string name,Vector3 pos,Vector3 scale,string material)
    {
        GameObject go=GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name=name; go.transform.position=pos; go.transform.localScale=scale;
        go.GetComponent<Renderer>().sharedMaterial=Mat(material);
        return go;
    }

    static void CreateMaterial(string name,Color color)
    {
        string path="Assets/"+name+".mat";
        Material m=new Material(Shader.Find("Standard"));
        m.color=color;
        AssetDatabase.CreateAsset(m,path);
    }

    static Material Mat(string name) => AssetDatabase.LoadAssetAtPath<Material>("Assets/"+name+".mat");
}
#endif
