using UnityEngine;

public class GameInputFrameReset : MonoBehaviour
{
    void LateUpdate()
    {
        GameInput.ClearFrameButtons();
    }
}
