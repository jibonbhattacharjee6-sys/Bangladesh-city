using UnityEngine;

public class VehicleSystem : MonoBehaviour
{
    public Transform player;
    public PlayerMotor playerMotor;
    public ThirdPersonCamera gameCamera;
    public float interactionDistance = 3.2f;
    ArcadeCar activeCar;

    void Update()
    {
        bool interact = GameInput.InteractPressed;
#if UNITY_EDITOR || UNITY_STANDALONE
        interact |= Input.GetKeyDown(KeyCode.E);
#endif
        if (!interact) return;

        if (activeCar != null) ExitVehicle();
        else EnterNearestVehicle();
    }

    void EnterNearestVehicle()
    {
        ArcadeCar[] cars = FindObjectsOfType<ArcadeCar>();
        ArcadeCar nearest = null;
        float best = interactionDistance;
        foreach (ArcadeCar car in cars)
        {
            float distance = Vector3.Distance(player.position, car.transform.position);
            if (distance < best) { best = distance; nearest = car; }
        }
        if (!nearest) return;

        activeCar = nearest;
        activeCar.SetControlled(true);
        player.gameObject.SetActive(false);
        playerMotor.enabled = false;
        gameCamera.target = activeCar.transform;
    }

    void ExitVehicle()
    {
        Vector3 exitPosition = activeCar.exitPoint
            ? activeCar.exitPoint.position
            : activeCar.transform.position - activeCar.transform.right * 2f;

        player.transform.position = exitPosition;
        player.gameObject.SetActive(true);
        playerMotor.enabled = true;
        activeCar.SetControlled(false);
        gameCamera.target = player;
        activeCar = null;
    }
}
