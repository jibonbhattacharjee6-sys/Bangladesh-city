using UnityEngine;
using UnityEngine.EventSystems;

public class TouchActionButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public enum ActionType { Run, Jump, Interact, Brake }
    public ActionType actionType;

    public void OnPointerDown(PointerEventData eventData)
    {
        Set(true);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        Set(false);
    }

    void Set(bool value)
    {
        switch (actionType)
        {
            case ActionType.Run: GameInput.Run = value; break;
            case ActionType.Jump: if (value) GameInput.JumpPressed = true; break;
            case ActionType.Interact: if (value) GameInput.InteractPressed = true; break;
            case ActionType.Brake: GameInput.Brake = value; break;
        }
    }
}
