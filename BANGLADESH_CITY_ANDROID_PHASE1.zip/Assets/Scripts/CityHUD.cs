using UnityEngine;
using UnityEngine.UI;

public class CityHUD : MonoBehaviour
{
    public Text titleText;
    public Text helpText;

    void Start()
    {
        if (titleText) titleText.text = "BANGLADESH CITY";
        if (helpText) helpText.text = "Joystick: Move  |  E: Enter/Exit Vehicle";
    }
}
