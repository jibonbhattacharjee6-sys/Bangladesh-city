using UnityEngine;
using UnityEngine.EventSystems;

public class TouchLookArea : MonoBehaviour, IDragHandler, IPointerDownHandler, IPointerUpHandler
{
    public float sensitivity = 0.12f;
    public void OnPointerDown(PointerEventData eventData) { GameInput.Look = Vector2.zero; }
    public void OnDrag(PointerEventData eventData)
    {
        GameInput.Look = eventData.delta * sensitivity;
    }
    public void OnPointerUp(PointerEventData eventData) { GameInput.Look = Vector2.zero; }
}
