using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class ArcadeCar : MonoBehaviour
{
    public float acceleration = 12f;
    public float reverseAcceleration = 7f;
    public float maxSpeed = 16f;
    public float steering = 65f;
    public Transform exitPoint;

    Rigidbody rb;
    bool controlled;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.mass = 1100;
        rb.drag = 0.18f;
        rb.angularDrag = 2.5f;
        rb.centerOfMass = new Vector3(0, -0.45f, 0);
    }

    void FixedUpdate()
    {
        if (!controlled) return;
        float vertical = 0, horizontal = 0;
        vertical = GameInput.Move.y;
        horizontal = GameInput.Move.x;
#if UNITY_EDITOR || UNITY_STANDALONE
        float keyVertical = Input.GetAxis("Vertical");
        float keyHorizontal = Input.GetAxis("Horizontal");
        if (Mathf.Abs(keyVertical) > 0.01f) vertical = keyVertical;
        if (Mathf.Abs(keyHorizontal) > 0.01f) horizontal = keyHorizontal;
#endif
        Vector3 velocity = rb.velocity;
        float forwardSpeed = Vector3.Dot(velocity, transform.forward);
        if (vertical > 0 && forwardSpeed < maxSpeed)
            rb.AddForce(transform.forward * vertical * acceleration, ForceMode.Acceleration);
        else if (vertical < 0 && forwardSpeed > -maxSpeed * 0.3f)
            rb.AddForce(transform.forward * vertical * reverseAcceleration, ForceMode.Acceleration);

        if (GameInput.Brake) rb.velocity *= 0.97f;

        float steerFactor = Mathf.Clamp01(rb.velocity.magnitude / 2.5f);
        rb.MoveRotation(rb.rotation * Quaternion.Euler(0,
            horizontal * steering * steerFactor * Time.fixedDeltaTime, 0));
    }

    public void SetControlled(bool value) { controlled = value; }
    public bool IsControlled => controlled;
}
