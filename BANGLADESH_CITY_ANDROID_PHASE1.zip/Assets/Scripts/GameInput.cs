using UnityEngine;

public static class GameInput
{
    public static Vector2 Move;
    public static Vector2 Look;
    public static bool Run;
    public static bool JumpPressed;
    public static bool InteractPressed;
    public static bool Brake;

    public static void ClearFrameButtons()
    {
        JumpPressed = false;
        InteractPressed = false;
    }
}
