using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerMotor : MonoBehaviour
{
    public Transform cameraTransform;
    public float walkSpeed = 3.5f;
    public float runSpeed = 5.5f;
    public float turnSpeed = 12f;
    public float jumpHeight = 1.1f;
    public float gravity = -22f;

    CharacterController controller;
    Vector3 verticalSpeed;

    void Awake() { controller = GetComponent<CharacterController>(); }

    void Update()
    {
        Vector2 input = GameInput.Move;
#if UNITY_EDITOR || UNITY_STANDALONE
        Vector2 keys = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        if (keys.sqrMagnitude > 0.01f) input = Vector2.ClampMagnitude(keys, 1f);
        bool run = GameInput.Run || Input.GetKey(KeyCode.LeftShift);
        bool jump = GameInput.JumpPressed || Input.GetKeyDown(KeyCode.Space);
#else
        bool run = GameInput.Run;
        bool jump = GameInput.JumpPressed;
#endif

        Vector3 forward = cameraTransform ? cameraTransform.forward : Vector3.forward;
        Vector3 right = cameraTransform ? cameraTransform.right : Vector3.right;
        forward.y = 0; right.y = 0;
        forward.Normalize(); right.Normalize();

        Vector3 move = forward * input.y + right * input.x;
        if (move.sqrMagnitude > 0.001f)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(move), turnSpeed * Time.deltaTime);
        }

        controller.Move(move.normalized * (run ? runSpeed : walkSpeed) * Time.deltaTime);

        if (controller.isGrounded && verticalSpeed.y < 0) verticalSpeed.y = -2f;
        if (jump && controller.isGrounded)
            verticalSpeed.y = Mathf.Sqrt(jumpHeight * -2f * gravity);

        verticalSpeed.y += gravity * Time.deltaTime;
        controller.Move(verticalSpeed * Time.deltaTime);
    }
}
