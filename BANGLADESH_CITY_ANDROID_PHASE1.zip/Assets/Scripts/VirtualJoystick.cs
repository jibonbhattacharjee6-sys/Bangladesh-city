using UnityEngine;
using UnityEngine.EventSystems;

public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public RectTransform background;
    public RectTransform handle;
    [Range(0.2f, 1f)] public float handleRange = 0.65f;

    public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);

    public void OnDrag(PointerEventData eventData)
    {
        if (!background || !handle) return;
        Vector2 local;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            background, eventData.position, eventData.pressEventCamera, out local);

        Vector2 half = background.rect.size * 0.5f;
        Vector2 normalized = new Vector2(
            half.x > 0 ? local.x / half.x : 0,
            half.y > 0 ? local.y / half.y : 0);
        normalized = Vector2.ClampMagnitude(normalized, 1f);
        handle.anchoredPosition = new Vector2(normalized.x * half.x * handleRange,
                                               normalized.y * half.y * handleRange);
        GameInput.Move = normalized;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        GameInput.Move = Vector2.zero;
        if (handle) handle.anchoredPosition = Vector2.zero;
    }
}
